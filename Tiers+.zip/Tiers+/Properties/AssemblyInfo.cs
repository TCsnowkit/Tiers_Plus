using System.Reflection;

[assembly: AssemblyProduct("Tiers+")] //Set this to the full name of the mod including spaces.
[assembly: AssemblyTitle("Tiers+")] //This is only used when mousing over a dll file in Windows explorer.
[assembly: AssemblyDescription("A Gadget mod for Roguelands")]
[assembly: AssemblyCompany("")] //Set this to your name/nickname and/or website
[assembly: AssemblyCopyright("© 2020 HaneyDev. All rights reserved.")] //Set this to your copyright name.
[assembly: AssemblyVersion(TiersPlus.TiersPlus.MOD_VERSION)] //Set this to the version of your mod.
[assembly: AssemblyFileVersion(TiersPlus.TiersPlus.MOD_VERSION)] //Set this to the version of your mod.