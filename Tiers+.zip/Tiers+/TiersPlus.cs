using GadgetCore.API;
using GadgetCore.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TiersPlus
{
    [Gadget("Tiers+", LoadPriority: 500)]
    public class TiersPlus : Gadget<TiersPlus>
    {
        public const string MOD_VERSION = "1.0";
        public const string CONFIG_VERSION = "1.0";

        protected override void Initialize()
        {
            Logger.Log("Tiers+ v" + Info.Mod.Version);

            ItemInfo energiteItem = new ItemInfo(ItemType.LOOT | ItemType.ORE | ItemType.TIER7, "Energite", "LOOT - ORE\nTIER: 7",
                GadgetCoreAPI.LoadTexture2D("Items/Energite")).Register(7);
            ItemInfo plasmaFernItem = new ItemInfo(ItemType.LOOT | ItemType.PLANT | ItemType.TIER7, "Plasma Fern", "LOOT - PLANT\nTIER: 7",
                GadgetCoreAPI.LoadTexture2D("Items/PlasmaFern")).Register(17);
            ItemInfo powerCrystalItem = new ItemInfo(ItemType.LOOT | ItemType.MONSTER | ItemType.TIER7, "Power Crystal", "LOOT - MONSTER PART\nTIER: 7",
                GadgetCoreAPI.LoadTexture2D("Items/PowerCrystal")).Register(27);
            ItemInfo lightingBugItem = new ItemInfo(ItemType.LOOT | ItemType.BUG | ItemType.TIER7, "Lightning Bug", "LOOT - BUG\nTIER: 7",
                GadgetCoreAPI.LoadTexture2D("Items/LightningBug")).Register(37);

            ItemInfo energiteEmblemItem = new ItemInfo(ItemType.EMBLEM | ItemType.ORE | ItemType.TIER7, "Energite Emblem", "Tier 7.\nA shiny Token. Used\nto forge items.",
                GadgetCoreAPI.LoadTexture2D("Items/EnergiteEmblem")).Register(107);
            ItemInfo fernEmblemItem = new ItemInfo(ItemType.EMBLEM | ItemType.PLANT | ItemType.TIER7, "Fern Emblem", "Tier 7.\nA shiny Token. Used\nto forge items.",
                GadgetCoreAPI.LoadTexture2D("Items/FernEmblem")).Register(117);
            ItemInfo powerEmblemItem = new ItemInfo(ItemType.EMBLEM | ItemType.MONSTER | ItemType.TIER7, "Power Emblem", "Tier 7.\nA shiny Token. Used\nto forge items.",
                GadgetCoreAPI.LoadTexture2D("Items/PowerEmblem")).Register(127);
            ItemInfo lightingEmblemItem = new ItemInfo(ItemType.EMBLEM | ItemType.BUG | ItemType.TIER7, "Lightning Emblem", "Tier 7.\nA shiny Token. Used\nto forge items.",
                GadgetCoreAPI.LoadTexture2D("Items/LightningEmblem")).Register(137);

            ItemInfo plasmaTracerItem = new ItemInfo(ItemType.CONSUMABLE, "Plasma Tracer", "Grants 3 portal uses to\nThe Plasma Zone.",
                GadgetCoreAPI.LoadTexture2D("Items/PlasmaTracer"), 32).Register();

            ItemInfo healthPack4Item = new ItemInfo(ItemType.CONSUMABLE, "Health Pack IV", "Restores 18 Health.",
                GadgetCoreAPI.LoadTexture2D("Items/HealthPack4")).Register();
            healthPack4Item.OnUse += (slot) =>
            {
                InstanceTracker.GameScript.GetComponent<AudioSource>().PlayOneShot((AudioClip)Resources.Load("Au/drink"), Menuu.soundLevel / 10f);
                InstanceTracker.GameScript.RecoverHP(18);
                return true;
            };
            ItemInfo manaPack4Item = new ItemInfo(ItemType.CONSUMABLE, "Mana Pack IV", "Restores 50 Mana.",
                GadgetCoreAPI.LoadTexture2D("Items/ManaPack4")).Register();
            manaPack4Item.OnUse += (slot) =>
            {
                InstanceTracker.GameScript.GetComponent<AudioSource>().PlayOneShot((AudioClip)Resources.Load("Au/drink"), Menuu.soundLevel / 10f);
                InstanceTracker.GameScript.RecoverMana(50);
                return true;
            };
            ItemInfo energyPack4Item = new ItemInfo(ItemType.CONSUMABLE, "Energy Pack IV", "Restores 100 Stamina.\nGrants a temporary\nspeed boost.",
                GadgetCoreAPI.LoadTexture2D("Items/EnergyPack4")).Register();
            energyPack4Item.OnUse += (slot) =>
            {
                InstanceTracker.GameScript.GetComponent<AudioSource>().PlayOneShot((AudioClip)Resources.Load("Au/drink"), Menuu.soundLevel / 10f);
                InstanceTracker.GameScript.RecoverStamina(100);
                InstanceTracker.GameScript.StartCoroutine(EnergyPackSpeedBoost(15, 10));
                return true;
            };

            GadgetCoreAPI.AddAlchemyStationRecipe(Tuple.Create(plasmaFernItem.GetID(), powerCrystalItem.GetID(), lightingBugItem.GetID()), new Item(healthPack4Item.GetID(), 1, 0, 0, 0, new int[3], new int[3]), 2);
            GadgetCoreAPI.AddAlchemyStationRecipe(Tuple.Create(plasmaFernItem.GetID(), lightingBugItem.GetID(), powerCrystalItem.GetID()), new Item(manaPack4Item.GetID(), 1, 0, 0, 0, new int[3], new int[3]), 2);
            GadgetCoreAPI.AddAlchemyStationRecipe(Tuple.Create(lightingBugItem.GetID(), plasmaFernItem.GetID(), powerCrystalItem.GetID()), new Item(energyPack4Item.GetID(), 1, 0, 0, 0, new int[3], new int[3]), 2);

            ((CraftMenuInfo)MenuRegistry.Singleton["Gadget Core:Crafter Menu"]).AddCraftPerformer(CraftMenuInfo.CreateSimpleCraftPerformer(
                Tuple.Create(new int[] { 136, 74, 136 }, new Item(plasmaTracerItem.GetID(), 1, 0, 0, 0, new int[3], new int[3]), 0)
            ));

            ObjectInfo testObject = new ObjectInfo(ObjectType.ORE, new Item(plasmaTracerItem.GetID(), 1, 0, 0, 0, new int[3], new int[3]), 1, GadgetCoreAPI.LoadTexture2D("Items/PlasmaTracer")).Register("TestObject");

            PlanetInfo plasmaZonePlanet = new PlanetInfo(PlanetType.NORMAL, "Plasma Zone", new Tuple<int, int>[] { Tuple.Create(-1, 1) }, GadgetCoreAPI.LoadAudioClip("Planets/Plasma Zone/Music"));
            plasmaZonePlanet.SetTerrainInfo(GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Entrance"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Zone"),
                GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/MidChunkFull"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/MidChunkOpen"),
                GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/SideH"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/SideV"));
            plasmaZonePlanet.SetBackgroundInfo(GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Parallax"),
                GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Background0"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Background1"),
                GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Background2"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Background3"));
            plasmaZonePlanet.SetPortalInfo(GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Sign"), GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Button"),
                GadgetCoreAPI.LoadTexture2D("Planets/Plasma Zone/Icon"));
            plasmaZonePlanet.Register("Plasma Zone");
            plasmaZonePlanet.AddWeightedWorldSpawn(testObject, 1);

            plasmaTracerItem.OnUse += (slot) =>
            {
                plasmaZonePlanet.PortalUses += 3;
                InstanceTracker.GameScript.GetComponent<AudioSource>().PlayOneShot((AudioClip)Resources.Load("Au/glitter"), Menuu.soundLevel / 10f);
                return true;
            };
        }

        private IEnumerator EnergyPackSpeedBoost(int power, float duration)
        {
            GameScript.MODS[16] += power;
            GameScript.MODS[17] += power;
            GameScript.MODS[18] += power;
            int boostedMoveModCount = GameScript.MODS[16];
            int boostedDashModCount = GameScript.MODS[17];
            int boostedJumpModCount = GameScript.MODS[18];
            yield return new WaitForSeconds(duration);
            if (GameScript.MODS[16] == boostedMoveModCount) GameScript.MODS[16] -= power;
            if (GameScript.MODS[17] == boostedDashModCount) GameScript.MODS[17] -= power;
            if (GameScript.MODS[18] == boostedJumpModCount) GameScript.MODS[18] -= power;
            yield break;
        }
    }
}